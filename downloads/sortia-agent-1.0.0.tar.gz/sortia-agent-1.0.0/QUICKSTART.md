# SORTIA Agent SDK Bundle
**Role:** Content Classifier  
**Live Portal:** https://d33u4991ehrqv3.cloudfront.net  
**Production API:** `https://n6r7yo1mvl.execute-api.us-east-1.amazonaws.com/api/classify`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://n6r7yo1mvl.execute-api.us-east-1.amazonaws.com/api/classify" \
     -H "Content-Type: application/json" \
     -d '{"text": "Formal notice of insurance claim dispute regarding auto collision damage on Highway 101."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
SORTIA_API_ENDPOINT=https://n6r7yo1mvl.execute-api.us-east-1.amazonaws.com/api/classify
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`SRT-YYYYMMDD-XXXXXX`).
