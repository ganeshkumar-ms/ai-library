"""
SORTIA Agent Quickstart Example
Enterprise AI Platform · Content Classifier
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("SORTIA_API_ENDPOINT", "https://n6r7yo1mvl.execute-api.us-east-1.amazonaws.com/api/classify")
LIVE_APP_URL = "https://d33u4991ehrqv3.cloudfront.net"

def run_sample():
    print(f"Connecting to SORTIA Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Formal notice of insurance claim dispute regarding auto collision damage on Highway 101."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
