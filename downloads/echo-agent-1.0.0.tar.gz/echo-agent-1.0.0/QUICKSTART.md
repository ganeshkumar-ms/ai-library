# ECHO Agent SDK Bundle
**Role:** Document Comparator  
**Live Portal:** https://d2e3xsh5ciq5sx.cloudfront.net  
**Production API:** `https://22s6be3850.execute-api.us-east-1.amazonaws.com/api/compare`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://22s6be3850.execute-api.us-east-1.amazonaws.com/api/compare" \
     -H "Content-Type: application/json" \
     -d '{"message": "Compare File 1: The supplier shall deliver products within 15 days. File 2: The supplier shall deliver products within 30 days and provide insurance."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
ECHO_API_ENDPOINT=https://22s6be3850.execute-api.us-east-1.amazonaws.com/api/compare
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`ECH-YYYYMMDD-XXXXXX`).
