"""
ECHO Agent Quickstart Example
Enterprise AI Platform · Document Comparator
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("ECHO_API_ENDPOINT", "https://22s6be3850.execute-api.us-east-1.amazonaws.com/api/compare")
LIVE_APP_URL = "https://d2e3xsh5ciq5sx.cloudfront.net"

def run_sample():
    print(f"Connecting to ECHO Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "message": "Compare File 1: The supplier shall deliver products within 15 days. File 2: The supplier shall deliver products within 30 days and provide insurance."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
