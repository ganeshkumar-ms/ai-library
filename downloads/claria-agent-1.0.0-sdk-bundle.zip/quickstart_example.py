"""
CLARIA Agent Quickstart Example
Enterprise AI Platform · Customer Communications Redesign
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("CLARIA_API_ENDPOINT", "https://d71pirbml8.execute-api.us-east-1.amazonaws.com/api/redesign")
LIVE_APP_URL = "https://d3a54sx4bbzktn.cloudfront.net"

def run_sample():
    print(f"Connecting to CLARIA Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Pursuant to Clause 14.2(b), failure to remit payment within 14 calendar days shall result in immediate termination of utility privileges without further recourse."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
