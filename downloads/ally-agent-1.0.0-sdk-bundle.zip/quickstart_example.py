"""
ALLY Agent Quickstart Example
Enterprise AI Platform · Web Accessibility Coach
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("ALLY_API_ENDPOINT", "https://987i4erb3d.execute-api.us-east-1.amazonaws.com/api/review")
LIVE_APP_URL = "https://d2b1l3a8mjms74.cloudfront.net"

def run_sample():
    print(f"Connecting to ALLY Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "message": "Review accessibility: <a href='/download'>Click here</a> to get our latest brochure. <img src='logo.png'>"
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
