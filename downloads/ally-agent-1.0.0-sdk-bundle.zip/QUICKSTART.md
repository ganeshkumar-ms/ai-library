# ALLY Agent SDK Bundle
**Role:** Web Accessibility Coach  
**Live Portal:** https://d2b1l3a8mjms74.cloudfront.net  
**Production API:** `https://987i4erb3d.execute-api.us-east-1.amazonaws.com/api/review`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://987i4erb3d.execute-api.us-east-1.amazonaws.com/api/review" \
     -H "Content-Type: application/json" \
     -d '{"message": "Review accessibility: <a href='/download'>Click here</a> to get our latest brochure. <img src='logo.png'>"}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
ALLY_API_ENDPOINT=https://987i4erb3d.execute-api.us-east-1.amazonaws.com/api/review
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`ALY-YYYYMMDD-XXXXXX`).
