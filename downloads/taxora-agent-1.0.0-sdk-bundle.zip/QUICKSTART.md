# TAXORA Agent SDK Bundle
**Role:** Taxonomy Agent  
**Live Portal:** https://duwz8hk1atmbr.cloudfront.net  
**Production API:** `https://yvw8dqk6c2.execute-api.us-east-1.amazonaws.com/api/classify`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://yvw8dqk6c2.execute-api.us-east-1.amazonaws.com/api/classify" \
     -H "Content-Type: application/json" \
     -d '{"text": "Enterprise Information Security Policy covering MFA and ISO 27001 controls."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
TAXORA_API_ENDPOINT=https://yvw8dqk6c2.execute-api.us-east-1.amazonaws.com/api/classify
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`TXR-YYYYMMDD-XXXXXX`).
