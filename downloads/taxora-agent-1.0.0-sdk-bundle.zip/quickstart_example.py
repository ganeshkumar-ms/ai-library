"""
TAXORA Agent Quickstart Example
Enterprise AI Platform · Taxonomy Agent
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("TAXORA_API_ENDPOINT", "https://yvw8dqk6c2.execute-api.us-east-1.amazonaws.com/api/classify")
LIVE_APP_URL = "https://duwz8hk1atmbr.cloudfront.net"

def run_sample():
    print(f"Connecting to TAXORA Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Enterprise Information Security Policy covering MFA and ISO 27001 controls."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
