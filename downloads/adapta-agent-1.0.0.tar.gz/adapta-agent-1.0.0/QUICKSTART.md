# ADAPTA Agent SDK Bundle
**Role:** Channel Message Adapter  
**Live Portal:** https://d36ns0rvegxqlv.cloudfront.net  
**Production API:** `https://2m1153u1z1.execute-api.us-east-1.amazonaws.com/api/adapt`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://2m1153u1z1.execute-api.us-east-1.amazonaws.com/api/adapt" \
     -H "Content-Type: application/json" \
     -d '{"text": "We are upgrading our core banking servers on Saturday Nov 22 from 2 AM to 5 AM UTC. ATM and card transactions remain active."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
ADAPTA_API_ENDPOINT=https://2m1153u1z1.execute-api.us-east-1.amazonaws.com/api/adapt
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`ADP-YYYYMMDD-XXXXXX`).
