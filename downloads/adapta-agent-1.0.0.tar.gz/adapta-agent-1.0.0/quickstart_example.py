"""
ADAPTA Agent Quickstart Example
Enterprise AI Platform · Channel Message Adapter
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("ADAPTA_API_ENDPOINT", "https://2m1153u1z1.execute-api.us-east-1.amazonaws.com/api/adapt")
LIVE_APP_URL = "https://d36ns0rvegxqlv.cloudfront.net"

def run_sample():
    print(f"Connecting to ADAPTA Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "We are upgrading our core banking servers on Saturday Nov 22 from 2 AM to 5 AM UTC. ATM and card transactions remain active."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
