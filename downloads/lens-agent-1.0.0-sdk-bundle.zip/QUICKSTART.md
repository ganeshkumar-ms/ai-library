# LENS Agent SDK Bundle
**Role:** Content Reviewer  
**Live Portal:** https://d1hwt5aw0fwzod.cloudfront.net  
**Production API:** `https://9h9cdk5cxi.execute-api.us-east-1.amazonaws.com/api/review`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://9h9cdk5cxi.execute-api.us-east-1.amazonaws.com/api/review" \
     -H "Content-Type: application/json" \
     -d '{"text": "Section 2 states 30 days to respond, but Section 6 states payment is due in 45 days."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
LENS_API_ENDPOINT=https://9h9cdk5cxi.execute-api.us-east-1.amazonaws.com/api/review
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`LNS-YYYYMMDD-XXXXXX`).
