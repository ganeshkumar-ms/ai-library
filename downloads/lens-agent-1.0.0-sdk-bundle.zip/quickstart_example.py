"""
LENS Agent Quickstart Example
Enterprise AI Platform · Content Reviewer
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("LENS_API_ENDPOINT", "https://9h9cdk5cxi.execute-api.us-east-1.amazonaws.com/api/review")
LIVE_APP_URL = "https://d1hwt5aw0fwzod.cloudfront.net"

def run_sample():
    print(f"Connecting to LENS Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Section 2 states 30 days to respond, but Section 6 states payment is due in 45 days."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
