# INDEX Agent SDK Bundle
**Role:** Metadata Tagger  
**Live Portal:** https://d33eb1zoxf1g08.cloudfront.net  
**Production API:** `https://tl1aqbynmf.execute-api.us-east-1.amazonaws.com/api/tag`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://tl1aqbynmf.execute-api.us-east-1.amazonaws.com/api/tag" \
     -H "Content-Type: application/json" \
     -d '{"text": "Master Services Agreement dated November 2026 between Acme Financial and Horizon Global regarding cloud modernization."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
INDEX_API_ENDPOINT=https://tl1aqbynmf.execute-api.us-east-1.amazonaws.com/api/tag
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`IXT-YYYYMMDD-XXXXXX`).
