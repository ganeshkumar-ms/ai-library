"""
INDEX Agent Quickstart Example
Enterprise AI Platform · Metadata Tagger
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("INDEX_API_ENDPOINT", "https://tl1aqbynmf.execute-api.us-east-1.amazonaws.com/api/tag")
LIVE_APP_URL = "https://d33eb1zoxf1g08.cloudfront.net"

def run_sample():
    print(f"Connecting to INDEX Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Master Services Agreement dated November 2026 between Acme Financial and Horizon Global regarding cloud modernization."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
