"""
GLANCE Agent Quickstart Example
Enterprise AI Platform · Interactive Statement Lab
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("GLANCE_API_ENDPOINT", "https://46woy3v8j7.execute-api.us-east-1.amazonaws.com/api/analyze")
LIVE_APP_URL = "https://d24bu68rg7e4m.cloudfront.net"

def run_sample():
    print(f"Connecting to GLANCE Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "text": "Statement Period: Oct 1 - Oct 31. Previous Balance: $1,420.00. Payments: $500.00. Finance Charges: $34.50. New Purchases: $890.20. Minimum Payment Due: $75.00."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
