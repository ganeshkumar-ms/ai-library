# GLANCE Agent SDK Bundle
**Role:** Interactive Statement Lab  
**Live Portal:** https://d24bu68rg7e4m.cloudfront.net  
**Production API:** `https://46woy3v8j7.execute-api.us-east-1.amazonaws.com/api/analyze`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://46woy3v8j7.execute-api.us-east-1.amazonaws.com/api/analyze" \
     -H "Content-Type: application/json" \
     -d '{"text": "Statement Period: Oct 1 - Oct 31. Previous Balance: $1,420.00. Payments: $500.00. Finance Charges: $34.50. New Purchases: $890.20. Minimum Payment Due: $75.00."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
GLANCE_API_ENDPOINT=https://46woy3v8j7.execute-api.us-east-1.amazonaws.com/api/analyze
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`GLN-YYYYMMDD-XXXXXX`).
