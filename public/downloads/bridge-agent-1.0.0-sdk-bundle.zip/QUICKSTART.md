# BRIDGE Agent SDK Bundle
**Role:** CMS Migrator  
**Live Portal:** https://d23utb1q5zn42x.cloudfront.net  
**Production API:** `https://hjwkic438k.execute-api.us-east-1.amazonaws.com/api/migrate`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://hjwkic438k.execute-api.us-east-1.amazonaws.com/api/migrate" \
     -H "Content-Type: application/json" \
     -d '{"content": "Blog article draft with title, author, publishDate, and body html content to migrate to Contentful."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
BRIDGE_API_ENDPOINT=https://hjwkic438k.execute-api.us-east-1.amazonaws.com/api/migrate
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`BRG-YYYYMMDD-XXXXXX`).
