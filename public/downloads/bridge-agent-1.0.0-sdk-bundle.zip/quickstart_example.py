"""
BRIDGE Agent Quickstart Example
Enterprise AI Platform · CMS Migrator
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("BRIDGE_API_ENDPOINT", "https://hjwkic438k.execute-api.us-east-1.amazonaws.com/api/migrate")
LIVE_APP_URL = "https://d23utb1q5zn42x.cloudfront.net"

def run_sample():
    print(f"Connecting to BRIDGE Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "content": "Blog article draft with title, author, publishDate, and body html content to migrate to Contentful."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
