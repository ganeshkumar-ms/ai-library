# CLARIA Agent SDK Bundle
**Role:** Customer Communications Redesign  
**Live Portal:** https://d3a54sx4bbzktn.cloudfront.net  
**Production API:** `https://d71pirbml8.execute-api.us-east-1.amazonaws.com/api/simplify`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://d71pirbml8.execute-api.us-east-1.amazonaws.com/api/simplify" \
     -H "Content-Type: application/json" \
     -d '{"text": "Pursuant to Clause 14.2(b), failure to remit payment within 14 calendar days shall result in immediate termination of utility privileges without further recourse."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
CLARIA_API_ENDPOINT=https://d71pirbml8.execute-api.us-east-1.amazonaws.com/api/simplify
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`CLR-YYYYMMDD-XXXXXX`).
