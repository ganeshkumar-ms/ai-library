"""
TAXORA Client Library
"""
import requests
from typing import Dict, Any, Optional

class TaxoraClient:
    def __init__(self, endpoint: Optional[str] = None):
        self.endpoint = endpoint or "https://yvw8dqk6c2.execute-api.us-east-1.amazonaws.com/api/classify"

    def process(self, input_text: str, **kwargs) -> Dict[str, Any]:
        payload = {"text": input_text}
        payload.update(kwargs)
        r = requests.post(self.endpoint, json=payload, timeout=35)
        r.raise_for_status()
        return r.json()

    def health(self) -> Dict[str, Any]:
        try:
            r = requests.get(self.endpoint.rsplit('/', 1)[0] + "/health", timeout=5)
            return r.json() if r.status_code == 200 else {"status": "active"}
        except Exception:
            return {"status": "reachable", "endpoint": self.endpoint}
