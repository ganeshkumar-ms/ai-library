# GRID Agent SDK Bundle
**Role:** Content Model Architect  
**Live Portal:** https://d2w2zkazeq82no.cloudfront.net  
**Production API:** `https://khag22rlna.execute-api.us-east-1.amazonaws.com/api/model`  

---

## 1. Quickstart Guide

### Option A: Direct Python Script
```bash
pip install -r requirements.txt
python quickstart_example.py
```

### Option B: Direct HTTP / cURL
```bash
curl -X POST "https://khag22rlna.execute-api.us-east-1.amazonaws.com/api/model" \
     -H "Content-Type: application/json" \
     -d '{"content": "Product Landing Page template with Hero Banner, Customer Testimonial Grid, Feature Matrix, and Pricing Table."}'
```

---

## 2. Configuration & Environment Variables
Copy `.env.example` to `.env` and configure:
```ini
GRID_API_ENDPOINT=https://khag22rlna.execute-api.us-east-1.amazonaws.com/api/model
AWS_REGION=us-east-1
LOG_LEVEL=INFO
```

---

## 3. Security & Governance Guardrails (PCI-DSS & GLBA)
- **Zero Raw Secrets:** Never submit raw AWS access keys, secret keys, or `.env` credential files.
- **Traceability:** Every response contains a verifiable trace ID (`GRD-YYYYMMDD-XXXXXX`).
