"""
GRID Agent Quickstart Example
Enterprise AI Platform · Content Model Architect
"""
import requests
import json
import os

API_ENDPOINT = os.getenv("GRID_API_ENDPOINT", "https://khag22rlna.execute-api.us-east-1.amazonaws.com/api/model")
LIVE_APP_URL = "https://d2w2zkazeq82no.cloudfront.net"

def run_sample():
    print(f"Connecting to GRID Live API: {API_ENDPOINT}")
    print(f"Web UI: {LIVE_APP_URL}\n")

    payload = {
        "content": "Product Landing Page template with Hero Banner, Customer Testimonial Grid, Feature Matrix, and Pricing Table."
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        print("Response received:")
        print(json.dumps(data, indent=2))
        if "trace_id" in data:
            print(f"\nVerification Trace ID: {data['trace_id']}")
    except Exception as e:
        print(f"API Invocation Error: {e}")

if __name__ == "__main__":
    run_sample()
